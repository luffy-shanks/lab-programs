# ExpressJS, ReactJS and MongoDB Lab Programs

The program code below is transcribed from the supplied PDF. The code has not been intentionally rewritten or modernized. Descriptions and file names are provided separately here.

## Folder layout

- `expressjs/` contains ExpressJS programs.
- `react-basis/` contains ReactJS programs, organized by question number.
- `mongodb/` contains MongoDB shell programs.

## ExpressJS

| Question | File name | Description |
|---|---|---|
| 1(a) | `expressjs/1a/app.js` | Defines routes, reads route parameters and query parameters, and builds a URL. |
| 1(b) | `expressjs/1b/app.js` | Uses POST to add student data, GET to retrieve it, and DELETE to remove a student. |
| 2(a) | `expressjs/2a/app.js` and `expressjs/2a/views/home.ejs` | Uses the EJS templating engine to render a page with dynamic name and course values. |
| 2(b) | `expressjs/2b/app.js` | Accepts HTML form data and displays the submitted name and email. |

## ReactJS (`react-basis/`)

| Question | File name | Description |
|---|---|---|
| 5(a) | `react-basis/5a-render-html/App.jsx` and `main.jsx` | Creates React elements and renders the App component into the root element. |
| 5(b) | `react-basis/5b-jsx-markup/App.jsx` | Uses JSX markup and inserts a JavaScript variable into the page. |
| 6(a) | `react-basis/6a-props-state/App.jsx` | Passes a name through props and uses state to count button clicks. |
| 6(b) | `react-basis/6b-css-sass/App.jsx`, `App.css`, `App.scss` | Displays student details and applies CSS and Sass styling. |
| 7(a) | `react-basis/7a-events/App.jsx` | Handles a button click and updates a message using state. |
| 7(b) | `react-basis/7b-conditional-rendering/App.jsx` | Displays login or welcome content based on a state condition. |
| 8(a) | `react-basis/8a-rendering-lists/App.jsx` | Uses `map()` to render a list of fruits. |

### React file placement

Copy the question folders into your existing `react-basis` folder. Each question has its own subfolder so files such as `App.jsx` do not overwrite one another. For 5(a), keep `App.jsx` and `main.jsx` together. For 6(b), keep `App.jsx`, `App.css`, and `App.scss` together.

## MongoDB

| Question | File name | Description |
|---|---|---|
| 8(b) | `mongodb/8b-crud-operations/8b.mongosh` | Inserts, finds, updates, and removes student documents using the shell methods shown in the source. |
| 9(a) | `mongodb/9a-create-drop-database-collections/9a.mongosh` | Selects a database, creates a collection, lists databases and collections, and drops them. |
| 9(b) | `mongodb/9b-find-limit-sort-index-aggregate/9b.mongosh` | Demonstrates find, limit, sort, createIndex, and aggregate operations. |

## Notes

- The PDF includes Questions 1, 2, and 5–9. Questions 3 and 4 are not present in the supplied PDF.
- The original MongoDB program uses the legacy shell methods `insert()`, `update()`, and `remove()` as shown in the PDF. They have not been replaced with newer methods.
- The React programs are separate examples. Open the relevant question folder when copying or running one program at a time.
